package com.AlgoDomain.Project.DTO;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "customerDetails")
public class CustomerDTO implements Serializable {
	
	
		private static final long serialVersionUID = 8876401261603074530L;

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int cid;
		
		private String cname;

		private String cmail;

		private long ccontact;

		private String caddress;

	

}
