package com.AlgoDomain.Project.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.AlgoDomain.Project.DTO.CustomerDTO;
import com.AlgoDomain.Project.DTO.ProductDTO;
import com.AlgoDomain.Project.DTO.SellerDTO;
import com.AlgoDomain.Project.Response.CustomerResponse;
import com.AlgoDomain.Project.Response.ProductResponse;
import com.AlgoDomain.Project.Response.SellerResponse;
import com.AlgoDomain.Project.Service.CustomerService;
import com.AlgoDomain.Project.Service.ProductService;
import com.AlgoDomain.Project.Service.SellerService;



@RestController
public class CustomerProductSellerController {

	@Autowired
	private ProductService productService;
	
	@Autowired
	private SellerService sellerService;
	
	@Autowired
	private CustomerService customerService;
	
	
	
	// Adding new customer
	@PostMapping("/addCustomer")
	public ResponseEntity<CustomerResponse> addCustomer(@RequestBody CustomerDTO customerDTO){
		CustomerDTO dto=customerService.addCustomer(customerDTO);
		if(dto!=null) {
			return new ResponseEntity<CustomerResponse>(new CustomerResponse(false,"Customer Inserted",dto),HttpStatus.ACCEPTED);
		}
		return new ResponseEntity<CustomerResponse>(new CustomerResponse(true, "Not Inserted"),HttpStatus.BAD_REQUEST);
	}
	
	
	
	
	// Deleting Customer using primary key(cid)
	@DeleteMapping("/deleteCustomer")
	public ResponseEntity<CustomerResponse> deleteCustomer(@RequestBody CustomerDTO cid){
		CustomerDTO dto=customerService.deleteCustomer(cid);
		if(dto!=null) {
			return new ResponseEntity<CustomerResponse>(new CustomerResponse(false, "Customer Deleted"),HttpStatus.ACCEPTED);
		}
		return new ResponseEntity<CustomerResponse>(new CustomerResponse(true, "Customer not Deleted"),HttpStatus.BAD_REQUEST);
	}
	

	
	// Adding new Seller 
		@PostMapping("/addSeller")
		public ResponseEntity<SellerResponse> addSeller(@RequestBody SellerDTO sellerDTO){
			SellerDTO dto=sellerService.addSeller(sellerDTO);
			if(dto!=null) {
				return new ResponseEntity<SellerResponse>(new SellerResponse(false,"Seller Inserted",dto),HttpStatus.ACCEPTED);
			}
			return new ResponseEntity<SellerResponse>(new SellerResponse(true, "Not Inserted"),HttpStatus.BAD_REQUEST);
		}
	
	
	
	// Deleting Seller using primary key(seller_id)
	@DeleteMapping("/deleteSeller")
	public ResponseEntity<SellerResponse> deleteSeller(@RequestBody SellerDTO sid){
		SellerDTO dto=sellerService.deleteSeller(sid);
		if(dto!=null) {
			return new ResponseEntity<SellerResponse>(new SellerResponse(false, "Seller Deleted"),HttpStatus.ACCEPTED);
		}
		return new ResponseEntity<SellerResponse>(new SellerResponse(true, "Seller not Deleted"),HttpStatus.BAD_REQUEST);
	}
	
	
	
}