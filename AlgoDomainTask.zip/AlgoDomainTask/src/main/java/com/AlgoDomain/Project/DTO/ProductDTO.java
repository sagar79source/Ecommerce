package com.AlgoDomain.Project.DTO;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="productDetail")
public class ProductDTO implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 2151824371938455887L;

	@Id
	private String pname;
	
	private String ptype;
	
	private String pcategory;
	
	private double pprice;
}