package com.AlgoDomain.Project.Service;

import com.AlgoDomain.Project.DTO.SellerDTO;

public interface SellerServiceInterface {

	SellerDTO addSeller(SellerDTO sellerDetail);

	SellerDTO deleteSeller(SellerDTO sid);
}
