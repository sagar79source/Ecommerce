package com.AlgoDomain.Project.DAO;

import org.springframework.data.repository.CrudRepository;

import com.AlgoDomain.Project.DTO.CustomerDTO;



public interface CustomerDAO extends CrudRepository<CustomerDTO, Integer> {
	

}
