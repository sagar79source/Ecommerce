package com.AlgoDomain.Project.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.AlgoDomain.Project.DTO.ProductDTO;



@Repository
public interface ProductDAO extends CrudRepository<ProductDTO, String>{

}
