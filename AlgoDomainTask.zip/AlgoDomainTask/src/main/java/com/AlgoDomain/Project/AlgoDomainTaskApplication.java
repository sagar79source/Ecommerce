package com.AlgoDomain.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgoDomainTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgoDomainTaskApplication.class, args);
	}

}
