package com.AlgoDomain.Project.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AlgoDomain.Project.DAO.ProductDAO;
import com.AlgoDomain.Project.DTO.ProductDTO;



@Service
public class ProductService implements ProductServiceInterface{

	@Autowired
	private ProductDAO productDAO;

	@Override
	public ProductDTO addProduct(ProductDTO productDetail) {
		 ProductDTO productDTO=productDAO.save(productDetail);
		return productDetail;
	}

	@Override
	public ProductDTO deleteProduct(ProductDTO pname) {
		productDAO.delete(pname);
		return pname;
	}
}
