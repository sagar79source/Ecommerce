package com.AlgoDomain.Project.Service;

import com.AlgoDomain.Project.DTO.ProductDTO;

public interface ProductServiceInterface {

	ProductDTO addProduct(ProductDTO product);
	
	ProductDTO deleteProduct(ProductDTO seller_name);
}
