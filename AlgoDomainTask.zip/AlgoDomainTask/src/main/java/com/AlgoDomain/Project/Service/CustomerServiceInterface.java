package com.AlgoDomain.Project.Service;

import com.AlgoDomain.Project.DTO.CustomerDTO;

public interface CustomerServiceInterface {

	CustomerDTO addCustomer(CustomerDTO customer);
	
	CustomerDTO deleteCustomer(CustomerDTO customer_id);
}
