package com.AlgoDomain.Project.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.AlgoDomain.Project.DTO.SellerDTO;



@Repository
public interface SellerDAO extends CrudRepository<SellerDTO, Integer> {
	

}
