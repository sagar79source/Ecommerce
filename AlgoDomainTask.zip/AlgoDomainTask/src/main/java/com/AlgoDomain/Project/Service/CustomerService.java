package com.AlgoDomain.Project.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AlgoDomain.Project.DAO.CustomerDAO;
import com.AlgoDomain.Project.DTO.CustomerDTO;



@Service
public class CustomerService implements CustomerServiceInterface{

	@Autowired
	private CustomerDAO customerDAO;

	@Override
	public CustomerDTO addCustomer(CustomerDTO customerDetails) {
		 CustomerDTO dto=customerDAO.save(customerDetails);
		return dto;
	}

	@Override
	public CustomerDTO deleteCustomer(CustomerDTO cid) {
		 customerDAO.delete(cid);
		return cid;
	}
	
	
}
