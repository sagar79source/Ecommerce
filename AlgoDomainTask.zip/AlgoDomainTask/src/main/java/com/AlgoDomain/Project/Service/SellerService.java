package com.AlgoDomain.Project.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AlgoDomain.Project.DAO.SellerDAO;
import com.AlgoDomain.Project.DTO.SellerDTO;



@Service
public class SellerService implements SellerServiceInterface{

	@Autowired
	private SellerDAO sellerDAO;

	@Override
	public SellerDTO addSeller(SellerDTO sellerDetail) {
		 SellerDTO sellerDTO=sellerDAO.save(sellerDetail);
		return sellerDetail;
	}

	@Override
	public SellerDTO deleteSeller(SellerDTO sid) {
		sellerDAO.delete(sid);
		return sid;
	}

	
	
	
}